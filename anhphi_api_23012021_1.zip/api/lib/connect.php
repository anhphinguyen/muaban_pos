<?php
    $db["hostname"] = "localhost";
    $db["username"] = "root";
    $db["password"] = "";
    $db["database"] = "db_muaban_pos";

    db_connect($db);

    date_default_timezone_set('Asia/Ho_Chi_Minh'); 
?>