<?php
$secret_key = base64_encode(md5("my_name_is_JunoPhraend"));
$time_expire = 1200; // 60*20